package com.Product.Tryout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TryoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
